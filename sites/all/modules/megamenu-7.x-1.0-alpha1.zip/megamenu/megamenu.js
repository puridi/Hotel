(function($) {
    
  Drupal.behaviors.megamenu = {
    attach:function(context) {

      var $megamenu = $('.megamenu-menu');
      var timeout = Drupal.settings.megamenu.timeout;
      var sizewait = Drupal.settings.megamenu.sizewait;
      var hoverwait = Drupal.settings.megamenu.hoverwait;
      var hovertimer = null;
      var sizetimer = null;
      var closetimer = null;
      var hoverParent = null;
      var hoverBin = null;
      var hoverSlots = null;
      var megaSlots = null;
      var megaParents = null;
      var hideOffset = -9000;
      var megaParents = $megamenu.find('.megamenu-parent');
      var megaParentTitles = $megamenu.find('.megamenu-parent-title');
      var megaBins = $megamenu.find('.megamenu-bin');
      var oldParentIdx = -1;
      var hoverParentIdx = -2;
      megaBins.css('top', hideOffset);
      var activeParent = megaParents.index($(megaParents).has('.active'));
      if (activeParent != -1) {
        megaParents.eq(activeParent).addClass('active');
      }

      function megamenu_open() {
        megamenu_canceltimer();

        if ($(this).hasClass('megamenu-parent-title')) {
          hoverParentIdx = megaParentTitles.index($(this));
        }
        else if ($(this).hasClass('megamenu-bin')) {
          hoverParentIdx = megaParents.index($(this).parents('.megamenu-parent'));
        }

        hoverParent = megaParents.eq(hoverParentIdx);

        if (hoverParentIdx != oldParentIdx) {
          megamenu_close();
          megamenu_hovertimer();
        }
        else {
          megamenu_display();
        }
      }

      function megamenu_display() {
        if (hoverParent) {
          // If the display doesn't have hover yet - trigger event.
          if (!hoverParent.hasClass('hovering')) {
            hoverParent.trigger('megamenu_open');
          }
          hoverParent.addClass('hovering');
          hoverBin = hoverParent.find('.megamenu-bin');
          /* display position */
          hoverBin.css('top', 'auto');
          /* display position end */
        }
      }

      function megamenu_close() {
        if (hoverParent) {
          oldParentIdx = $('.megamenu-parent').index(hoverParent);
        }
        for (var i = 0 ; i < megaParents.length ; i++) {
          megaParents.trigger('megamenu_close');
          megaParents.eq(i).removeClass('hovering');
        }
        if (hoverBin) hoverBin.css('top', hideOffset);
      }

      function megamenu_closeAll() {
        if (hoverBin) hoverBin.css('top', hideOffset);
        for (var i = 0 ; i < megaParents.length ; i++) {
          megaParents.trigger('megamenu_close');
          megaParents.eq(i).removeClass('hovering');
        }
        oldParentIdx = -1;
      }

      function megamenu_stopPropagation(event) {
        event.stopPropagation();
      }

      function megamenu_timer() {
        megamenu_canceltimer();
        megamenu_cancelhovertimer();
        closetimer = window.setTimeout(megamenu_closeAll, timeout);
      }

      function megamenu_canceltimer() {
        if (closetimer) {
          window.clearTimeout(closetimer);
          closetimer = null;
        }
      }

      function megamenu_hovertimer() {
        megamenu_cancelhovertimer();
        hovertimer = window.setTimeout(megamenu_display, hoverwait);
      }

      function megamenu_cancelhovertimer() {
        if (hovertimer) {
          window.clearTimeout(hovertimer);
          hovertimer = null;
        }
      }

      function megamenu_sizetimer() {
        /* waits to resize on initial call to accommodate browser draw */
        sizetimer = window.setTimeout(megamenu_sizer, sizewait);
      }

      function megamenu_sizer() {

        for (var k=0 ; k < megaBins.length ; k++) {

          /* resets to bin sizes and position before sizing */
          megaBins.eq(k).css('left', 0 + 'px');
          megaBins.eq(k).css('width', 0 + 'px');

          var megaSlots = megaBins.eq(k).find('.megamenu-slot');

          /* auto bin width start */

          var i = 0;

          if (megaBins.eq(k).hasClass('megamenu-slots-columnar')) {
            var slotTotalWidth = 0;
            for (i = 0 ; i < megaSlots.length ; i++) {

              slotTotalWidth += megaSlots.eq(i).outerWidth(true);

              if (slotTotalWidth > $(window).width()) {
                slotTotalWidth = 0;
                for (var j=0 ; j < i ; j++) {
                  slotTotalWidth += megaSlots.eq(i).outerWidth(true);
                }
                break;
              }
            }
            megaBins.eq(k).css('width' , slotTotalWidth);
            megaBins.eq(k).width(slotTotalWidth);
          }
          else {
            /* set bin width for vertical slots */
            megaBins.eq(k).css('width' , megaSlots.eq(0).outerWidth(true));
          }
          /* auto bin width end */

          /* off-page shift start */
          var edgeOverlap = ($(window).width() - (megaBins.eq(k).offset().left + megaBins.eq(k).outerWidth(true)));

          if (edgeOverlap < 0) {
            megaBins.eq(k).css('left',(edgeOverlap) + 'px');
          }
          /* off-page shift end */
        }
      }

      // Open Mega Menu Function - bound
      function megamenu_open_progress() {
        if ($(this).find('ul.megamenu-bin').get(0)) {
          $(this).find('h2').addClass('megamenu-active');
        }
      }
      function megamenu_close_progress() {
        $(this).find('h2').removeClass('megamenu-active');
      }

      $('.megamenu-parent').bind('megamenu_open', megamenu_open_progress);
      $('.megamenu-parent').bind('megamenu_close', megamenu_close_progress);

      $('.megamenu-parent-title').bind('mouseover', megamenu_open);
      $('.megamenu-parent-title').bind('mouseout', megamenu_timer);

      $('.megamenu-bin').bind('mouseover', megamenu_open);
      $('.megamenu-bin').bind('mouseout', megamenu_timer);

      $("body").bind('click', megamenu_closeAll);
      $(".megamenu-menu").bind('click', megamenu_stopPropagation);

      $(window).bind('resize', megamenu_sizer);
      megamenu_sizetimer();
    }
  }
})(jQuery);
