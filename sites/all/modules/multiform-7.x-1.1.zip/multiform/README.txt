== SUMMARY ==
This is an API module which lets you put several forms into one <form>.

== USAGE ==
For code example, check multiform.example.inc file.